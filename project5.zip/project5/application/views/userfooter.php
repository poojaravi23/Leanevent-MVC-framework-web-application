<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html> 	
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/leanevent.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<link rel='stylesheet' href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
		<title>  Inicio Individual </title>
	</head>
	<body class="wrapper" >


		<footer class ="foot">
			<p style="padding-top:60px;">Copyright &copy2019 All rights reserved|This web is made with &#9825; by <a href="#" style="color: #FFC300;">DiazApps</a> 
			</p><a href="#up"><button class="mybtn"><i style="font-size:70%;color:white;"class="fas fa-arrow-up"></i></button></a>

		</footer>
	</body>
	</html>