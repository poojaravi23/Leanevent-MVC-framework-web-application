<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html> 	
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/leanevent.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<link rel='stylesheet' href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
		<title>  Inicio </title>
	</head>
	<body class="wrapper" >
		<span id="up"></span>
		
		<div>
			 <img class="homebanner" src="<?php echo base_url();?>/imagenes/bannerlean1.jpg">
			 <img class="overlapban" src="<?php echo base_url();?>/imagenes/logo-blanco.png">
		</div>

		
	</body>
</html>

