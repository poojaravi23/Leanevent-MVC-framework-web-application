<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html> 	
<html>   
	<head>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/css/leanevent.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<link rel='stylesheet' href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
		<title>  INICIO </title>
	</head> 
	<body class="wrapper" >
	    <footer style="top:1700px;" class ="foot">
	    	<p style="font-weight: bold;">LEAN EN LAS REDES SOCIALES</p><br>
	    	<i style="padding-left:10px;color:#FFC133;"class="fab fa-twitter"></i>
	    	<i style="padding-left:10px;color:#FFC133;" class="fab fa-facebook-f"></i>
	    	<i style="padding-left:10px;color:#FFC133;" class="fab fa-instagram"></i>
		    <p style="padding-top:60px;">Copyright &copy2019 All rights reserved|This web is made with &#9825; by <a href="#" style="color: #FFC133;">DiazApps</a> 
		    </p><a href="#up"><button class="mybtn"><i style="font-size:70%;color:white;"class="fas fa-arrow-up"></i></button></a>	  
		</footer>
	</body>
</html>
